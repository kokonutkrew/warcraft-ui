local L = LibStub("AceLocale-3.0"):NewLocale("Details", "frFR") 
if not L then return end 

@localization(locale="frFR", format="lua_additive_table")@