local L = LibStub("AceLocale-3.0"):NewLocale("Details", "esMX") 
if not L then return end 

@localization(locale="esMX", format="lua_additive_table")@