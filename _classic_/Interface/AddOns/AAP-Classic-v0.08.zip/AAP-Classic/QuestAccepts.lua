if (tonumber(string.sub(AAPClassic.Build, 1,1)) > 2) then
	return
end
AAPClassic.QL = {}

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		