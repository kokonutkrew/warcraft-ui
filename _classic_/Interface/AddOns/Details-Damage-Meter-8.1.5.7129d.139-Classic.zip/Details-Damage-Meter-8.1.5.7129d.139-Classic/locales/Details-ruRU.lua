local L = LibStub("AceLocale-3.0"):NewLocale("Details", "ruRU") 
if not L then return end 

@localization(locale="ruRU", format="lua_additive_table")@