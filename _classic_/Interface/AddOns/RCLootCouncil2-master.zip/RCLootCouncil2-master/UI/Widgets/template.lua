local _, addon = ...

local name = "TEMPLATE"
local Object = {}

function Object:New(parent, name)

end

addon.UI:RegisterElement(Object, name)
