# Lib: HereBeDragons

## [2.01-release-5-gcd7e0dd](https://github.com/Nevcairiel/HereBeDragons/tree/cd7e0ddc76082130783f138b824f7659b6a4c3f3) (2019-05-26)
[Full Changelog](https://github.com/Nevcairiel/HereBeDragons/compare/2.01-release...cd7e0ddc76082130783f138b824f7659b6a4c3f3)

- Add World Map Data for Classic  
- Preliminary WoW Classic support  
- Add travis-ci support  
- Add LuaCheck and EditorConfig, and clean sources to pass  
- Fill in the map list by iterating over all known maps, in addition to processing the child tree  
