# WoW-Pro-Guides
A World of Warcraft addon bringing WoW-Pro.com's guides into the game.

This repository is for the code for the addon.

Any bugs with the guides themselves should go to http://wow-pro.com/

