TourGuide:RegisterGuide("JamHin5050", "The Hinterlands", "Jame", "50", "50", "JamSea5051", "Alliance", function() return [[
R Aerie Peak |QID|1452|
T Rhapsody's Kalimdor Kocktail |N|The path starts near  | |QID|1452|M|21.00,48.00|
A Rhapsody's Tale |QID|1469|
C Sprinkle's Secret Ingredient |N|Go into the water here and look for a Violet Tragan.  Loot it. | |QID|2641|M|40.00,59.90|
C Food for Baby |N|Kill Silvermane Stalkers until you get the 5 flanks needed for the quest. | |QID|4297|M|63.00,50.00|
H Aerie Peak |QID|4297| |N|Hearth or run to Aerie Peak.|
T Food for Baby |QID|4297|M|14.2,43.6|
A Becoming a Parent |QID|4298|M|14.2,43.6|
T Becoming a Parent |QID|4298|M|14.2,43.6|
F Stormwind City |QID|1469| |N|Fly to Stormwind City. |M|11.10,46.15|
T Rhapsody's Tale |QID|1469| |Z|Stormwind City|
R Ironforge |QID|3441| |N|Take the Tram to Ironforge.|
h Ironforge |QID|3441| |N|Make Ironforge your home location. |M|18.50,51.60|
N Sell junk, repair, restock, train skills. |QID|3441| |N|Sell junk, repair, restock, train skills. |
N Silk Cloth |QID|3441| |N|Make sure you have 15 Silk Cloth.  Do not throw it away.|
N Mithril Casing |QID|3441| |N|Make sure you have a Mithril Casing.  Do not throw it away.| |L|10561 1|
F Thelsamar |QID|3441| |N|Fly to Thelsamar. | |Z|Ironforge|M|55.50,47.70|
]]
end)
