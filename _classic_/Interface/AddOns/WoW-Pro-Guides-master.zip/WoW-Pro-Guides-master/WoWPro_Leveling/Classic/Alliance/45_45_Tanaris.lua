TourGuide:RegisterGuide("JamTan4545", "Tanaris", "Jame", "45", "45", "JamFer4547", "Alliance", function() return [[
R Gadgetzan |QID|2864|
T Tran'rek |QID|2864|M|51.6,26.8|
A Wastewander Justice |QID|1690|M|52.5,28.5|
A Water Pouch Bounty |QID|1707|M|52.5,28.5|
A Handle With Care |QID|3022|M|52.4,26.9|
A WANTED: Caliph Scorpidsting |N| | |QID|2781|M|51.80,27.00|
A WANTED: Andre Firebeard |QID|2875|M|51.8,27.0|
h Gadgetzan |QID|2872| |N|Make Gadgetzan your home location. |M|52.50,27.90|
N Kill Bandits at Noonshade Ruins |QID|2872| |N|Go to this location and clear the camp, then continue east. |M|61.00,24.00|
A Pirate Hats Ahoy! |QID|8365|M|66.6,22.3|
A Screecher Spirits |QID|3520|M|67.0,22.4|
A Southsea Shakedown |QID|8366|M|67.1,23.9|
T Stoley's Debt |QID|2872|M|67.1,23.9|
A Stoley's Shipment |QID|2873|M|67.1,23.9|
C Water Pouch Bounty |N|Go back to Noonshade Ruins and kill Bandits here to get the water pouches for this quest. | |QID|1707|M|61.00,24.00|
C Wastewander Justice |N|Kill the rest of the mobs needed for this quest. | |QID|1690|
T Water Pouch Bounty |QID|1707|M|52.5,28.5|
T Wastewander Justice |QID|1690|M|52.5,28.5|
A More Wastewander Justice |QID|1691|M|52.5,28.5|
R Thousand Needles |QID|1137| |N|Run north to Thousand Needles. |M|51.00,18.00|
T News for Fizzle |QID|1137|M|78.1,77.1|
T Parts for Kravel |QID|1112|M|77.8,77.3|
T Goblin Sponsorship (part 5) |QID|1183|M|80.2,75.9|
A Keeping Pace |QID|1190|M|80.2,75.9|
C Keeping Pace |N|Talk to Zamek to get him to start moving.  Follow him until he sets up the explosives, then loot the Unguarded Plans when Rizzle is distracted. | |QID|1190|M|79.80,77.00|
T Keeping Pace |QID|1190|M|77.2,77.4|
A Rizzle's Schematics |QID|1194|M|77.2,77.4|
T Rizzle's Schematics |QID|1194|M|80.2,75.9|
H Gadgetzan |QID|2969| |N|Hearth or run to Gadgetzan.|
F Thalanaar |QID|2969| |N|Fly to Thalanaar (Feralas) (51.00, 29.30)|
]]
end)
